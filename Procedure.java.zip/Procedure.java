public class Procedure {
    private String procedureName;
    private String procedureDate;
    private String practitionerName;
    private double charges;

  
    public Procedure() {
        procedureName = "";
        procedureDate = "";
        practitionerName = "N/A"; 
        charges = 0.0;
    }

  
    public Procedure(String name, String date) {
        procedureName = name;
        procedureDate = date;
        practitionerName = "N/A";
        charges = 0.0; 
    }

    
    public Procedure(String name, String date, String practitioner, double charge) {
        procedureName = name;
        procedureDate = date;
        practitionerName = practitioner;
        charges = charge;
    }

   
    public double getCharges() {
        return charges;
    }


    public String toString() {
        return String.format("%-15s %-15s %-20s $%.2f", procedureName, procedureDate, practitionerName, charges);
    }


	public String getPractitionerName() {
		
		return practitionerName;
	}


	public String getProcedureName() {
	
		return procedureName;
	}


	public String getProcedureDate() {
		
		return procedureDate;
	}
}

