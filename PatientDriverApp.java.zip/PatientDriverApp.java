/*
 * Class: CMSC203 
 * Instructor: Ashique Tanveer
 * Description: Retrieving patient Information 
 * Due EXTENDED: 03/14/2025
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: _Hana___Mahdood___
*/

public class PatientDriverApp {
    public static void main(String[] args) {
      
        Patient patient = new Patient(
            "Hana", "N/A", "Mahdood", 
            "456 Maple Street", "Silver Spring", "MD", "20910", 
            "301-555-1234", "Sarah Mahdood", "301-555-5678"
        );

        Procedure p1 = new Procedure("X-ray", "03/14/2025", "Dr. Jamison", 150.75);
        Procedure p2 = new Procedure("MRI", "03/14/2025", "Dr. Smith", 800.50);
        Procedure p3 = new Procedure("Blood Test", "03/14/2025", "Dr. Irvine", 120.30);


        System.out.println("Patient info:");
        System.out.println("Name:\t\t" + patient.buildFullName());
        System.out.println("Address:\t" + patient.buildAddress());
        System.out.println("Emergency Contact:\t" + patient.buildEmergencyContact());
        System.out.println();


        displayProcedure(p1);
        displayProcedure(p2);
        displayProcedure(p3);

    
        double totalCharges = calculateTotalCharges(p1, p2, p3);
        System.out.printf("Total Charges:\t$%,.2f\n", totalCharges);
        System.out.println();
        
        // Student info
        System.out.println("Student Name:\tJulie Taylor");
        System.out.println("MCT:\t\tMC777777");
        System.out.println("Due Date:\t06/12/2023");
    }

    public static void displayProcedure(Procedure p) {
        System.out.println("Procedure:\t" + p.getProcedureName());
        System.out.println("Procedure Date:\t" + p.getProcedureDate());
        System.out.println("Practitioner:\t" + p.getPractitionerName());
        System.out.printf("Charge:\t\t$%,.2f\n", p.getCharges());
        System.out.println();
    }

    public static double calculateTotalCharges(Procedure p1, Procedure p2, Procedure p3) {
        return p1.getCharges() + p2.getCharges() + p3.getCharges();
    }
}
