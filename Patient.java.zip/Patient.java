public class Patient {
    private String firstName, middleName, lastName;
    private String address, city, state, zip;
    private String phoneNumber;
    private String emergencyContactName, emergencyContactPhone;

    public Patient() {
        firstName = middleName = lastName = "";
        address = city = state = zip = "N/A";
        phoneNumber = "N/A";
        emergencyContactName = emergencyContactPhone = "N/A";
    }

    public Patient(String first, String middle, String last) {
        firstName = first;
        middleName = middle;
        lastName = last;
        address = city = state = zip = "N/A";  // Default values
        phoneNumber = "N/A";
        emergencyContactName = emergencyContactPhone = "N/A";
    }

    public Patient(String first, String middle, String last, String addr, String c, String s, String z, String phone, String eName, String ePhone) {
        firstName = first;
        middleName = middle;
        lastName = last;
        address = addr;
        city = c;
        state = s;
        zip = z;
        phoneNumber = phone;
        emergencyContactName = eName;
        emergencyContactPhone = ePhone;
    }

    public String buildFullName() {
        return firstName + " " + (middleName.isEmpty() ? "" : middleName + " ") + lastName;
    }

    public String buildAddress() {
        return address + ", " + city + ", " + state + " " + zip;
    }

    public String buildEmergencyContact() {
        return emergencyContactName + " (" + emergencyContactPhone + ")";
    }

    public String toString() {
        return "Patient: " + buildFullName() + "\nAddress: " + buildAddress() + "\nPhone: " + phoneNumber + "\nEmergency Contact: " + buildEmergencyContact();
    }
}