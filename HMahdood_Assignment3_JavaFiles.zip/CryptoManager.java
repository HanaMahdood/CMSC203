/*
 * Class: CMSC203 
 * Instructor: Ashique Tanveer
 * Description: 
 * Due: 03/28/2025
 * Platform/compiler:
 * I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Hana Mahdood
*/



public class CryptoManager{
	
	private static final char LOWER_RANGE = ' ';
	private static final char UPPER_RANGE = '_';
	private static final int RANGE = UPPER_RANGE - LOWER_RANGE + 1;
	
public static boolean isStringInBounds(String plainText) {
  for (int i = 0; i < plainText.length(); i++) {
      int asciiValue = (int) plainText.charAt(i);
      if (asciiValue < LOWER_RANGE || asciiValue > UPPER_RANGE) {
          return false;  
      }
  }
  return true;
}
public static String caesarEncryption(String plainText, int key) {
  if (!isStringInBounds(plainText)) {
      return "The selected string is not in bounds, Try again.";
  }
  StringBuilder encryptedText = new StringBuilder();
  key = key % (UPPER_RANGE - LOWER_RANGE + 1);  
  for (int i = 0; i < plainText.length(); i++) {
      int asciiValue = (int) plainText.charAt(i);
      int newAsciiValue = asciiValue + key;
      while (newAsciiValue > UPPER_RANGE) {
          newAsciiValue -= (UPPER_RANGE - LOWER_RANGE + 1); 
      }
      encryptedText.append((char) newAsciiValue);
  }
  return encryptedText.toString();
}
public static String caesarDecryption(String encryptedText, int key) {
  if (!isStringInBounds(encryptedText)) {
      return "The selected string is not in bounds, Try again.";
  }
  StringBuilder decryptedText = new StringBuilder();
  key = key % (UPPER_RANGE - LOWER_RANGE + 1);  


  for (int i = 0; i < encryptedText.length(); i++) {
      int asciiValue = (int) encryptedText.charAt(i);
      int newAsciiValue = asciiValue - key;
      while (newAsciiValue < LOWER_RANGE) {
          newAsciiValue += (UPPER_RANGE - LOWER_RANGE + 1); 
      }
      decryptedText.append((char) newAsciiValue);
  }
  return decryptedText.toString();
}
public static String bellasoEncryption(String plainText, String bellasoStr) {
	   if (!isStringInBounds(plainText)) {
	       return "The selected string is not in bounds, Try again.";
	   }
	   StringBuilder encryptedText = new StringBuilder();
	   int bellasoLen = bellasoStr.length();
	   for (int i = 0; i < plainText.length(); i++) {
	       int plainAscii = (int) plainText.charAt(i);
	       int keyAscii = (int) bellasoStr.charAt(i % bellasoLen);
	     
	       int encryptedAscii = plainAscii + keyAscii;
	       
	       while (encryptedAscii > UPPER_RANGE) {
	           encryptedAscii -= RANGE;
	       }
	       while (encryptedAscii < LOWER_RANGE) {
	           encryptedAscii += RANGE;
	       }
	       encryptedText.append((char) encryptedAscii);
	   }
	   return encryptedText.toString();
	}
	public static String bellasoDecryption(String encryptedText, String bellasoStr) {
	   if (!isStringInBounds(encryptedText)) {
	       return "The selected string is not in bounds, Try again.";
	   }
	   StringBuilder decryptedText = new StringBuilder();
	   int bellasoLen = bellasoStr.length();
	   for (int i = 0; i < encryptedText.length(); i++) {
	       int encryptedAscii = (int) encryptedText.charAt(i);
	       int keyAscii = (int) bellasoStr.charAt(i % bellasoLen);
	 
	       int decryptedAscii = encryptedAscii - keyAscii;
	      
 	       while (decryptedAscii < LOWER_RANGE) {
	           decryptedAscii += RANGE;
	       }
	       while (decryptedAscii > UPPER_RANGE) {
	           decryptedAscii -= RANGE;
	       }
	       decryptedText.append((char) decryptedAscii);
	   }
	   return decryptedText.toString();
	}
}
